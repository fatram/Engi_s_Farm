Dilakukan pembagian pada subfolder agar memperjelas pembagian kelas

Note :
Karena tidak bisa multipe parent subfolder, pada file renderable tetap dimasukkan file turunannya walaupun pada class file lain sudah didefinisikan